"""Module 2 - Unit 4 - T12: Kruskal's algorithm for a telemedicine network.
Own merge sort, own union-find, own Prim (array based). No heapq / sorted()."""

NODES = ["DH"] + [f"PHC{i}" for i in range(1, 21)]   # district hospital + 20 PHCs = 21 nodes

# (u, v, cost in lakh rupees) - synthetic data
EDGES = [
 (0,1,12),(0,2,15),(0,3,9),(1,2,7),(1,4,11),(2,3,10),(2,5,14),(3,6,13),(4,5,6),(4,7,8),
 (5,6,5),(5,8,16),(6,9,12),(7,8,9),(7,10,14),(8,9,4),(8,11,10),(9,12,15),(10,11,7),(10,13,13),
 (11,12,6),(11,14,12),(12,15,9),(13,14,8),(13,16,11),(14,15,5),(14,17,14),(15,18,10),(16,17,7),(16,19,12),
 (17,18,6),(17,20,9),(18,20,8),(19,20,5),(3,4,17),(6,7,18),(9,10,16),(12,13,19),(15,16,17),(18,19,15)]

def merge_sort(a, ctr):
    if len(a) <= 1: return a
    m = len(a) // 2
    L = merge_sort(a[:m], ctr); R = merge_sort(a[m:], ctr)
    out = []; i = j = 0
    while i < len(L) and j < len(R):
        ctr[0] += 1
        if L[i][2] <= R[j][2]: out.append(L[i]); i += 1
        else: out.append(R[j]); j += 1
    out.extend(L[i:]); out.extend(R[j:])
    return out

class UnionFind:
    def __init__(self, n):
        self.p = list(range(n)); self.r = [0] * n
    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb: return False
        if self.r[ra] < self.r[rb]: ra, rb = rb, ra
        self.p[rb] = ra
        if self.r[ra] == self.r[rb]: self.r[ra] += 1
        return True

def connected(n, edges):
    uf = UnionFind(n)
    for u, v, w in edges: uf.union(u, v)
    r = uf.find(0)
    return all(uf.find(i) == r for i in range(n))

def kruskal(n, edges, trace=False):
    ctr = [0]
    s = merge_sort(list(edges), ctr)
    uf = UnionFind(n); chosen = []; total = 0; checks = 0
    for u, v, w in s:
        checks += 1
        ok = uf.union(u, v)
        if trace:
            print(f"  {NODES[u]:>5}-{NODES[v]:<5} cost {w:>2} -> {'ACCEPT' if ok else 'REJECT (cycle)'}")
        if ok:
            chosen.append((u, v, w)); total += w
            if len(chosen) == n - 1: break
    return chosen, total, ctr[0], checks

def prim(n, edges):
    INF = 10 ** 9
    M = [[INF] * n for _ in range(n)]
    for u, v, w in edges:
        if w < M[u][v]: M[u][v] = M[v][u] = w
    vis = [False] * n; key = [INF] * n; par = [-1] * n; key[0] = 0
    total = 0; chosen = []
    for _ in range(n):
        best = -1
        for i in range(n):
            if not vis[i] and (best == -1 or key[i] < key[best]): best = i
        if key[best] == INF: break
        vis[best] = True; total += key[best]
        if par[best] != -1: chosen.append((par[best], best, key[best]))
        for j in range(n):
            if not vis[j] and M[best][j] < key[j]:
                key[j] = M[best][j]; par[j] = best
    return chosen, total

def show(chosen, total):
    for u, v, w in chosen: print(f"  {NODES[u]:>5} -- {NODES[v]:<5} cost {w}")
    print(f"  Edges chosen = {len(chosen)}, Total cost = {total} lakh")

def menu():
    edges = list(EDGES); n = len(NODES)
    print(f"({n} nodes and {len(edges)} candidate links loaded)")
    while True:
        print("\n===== MODULE 2: TELEMEDICINE NETWORK (KRUSKAL'S ALGORITHM) =====")
        print("1. Display candidate links (unsorted)")
        print("2. Display sorted edge list")
        print("3. Run Kruskal with step-by-step trace")
        print("4. Show MST edges and total cost")
        print("5. Compare Kruskal with Prim")
        print("6. Add a new link")
        print("7. Back to main menu")
        ch = input("Enter choice: ").strip()
        if ch == "1":
            for u, v, w in edges: print(f"  {NODES[u]:>5} -- {NODES[v]:<5} cost {w}")
            print(f"  Total links: {len(edges)}")
        elif ch == "2":
            c = [0]; s = merge_sort(list(edges), c)
            for u, v, w in s: print(f"  cost {w:>2}: {NODES[u]} -- {NODES[v]}")
            print(f"  (merge sort comparisons = {c[0]})")
        elif ch == "3":
            if not connected(n, edges): print("  Network is not connected: no spanning tree exists.")
            else:
                ch_, tot, sc, cc = kruskal(n, edges, True)
                print(f"  Total cost = {tot} lakh")
        elif ch == "4":
            if not connected(n, edges): print("  Network is not connected: no spanning tree exists.")
            else:
                c, t, _, _ = kruskal(n, edges); show(c, t)
        elif ch == "5":
            if not connected(n, edges): print("  Network is not connected: no spanning tree exists.")
            else:
                kc, kt, sc, cc = kruskal(n, edges); pc, pt = prim(n, edges)
                print(f"  Kruskal total cost = {kt} ({len(kc)} edges, sort comparisons {sc}, cycle checks {cc})")
                print(f"  Prim    total cost = {pt} ({len(pc)} edges)")
                print("  Costs are", "EQUAL - both give a minimum spanning tree." if kt == pt else "DIFFERENT - check data.")
        elif ch == "6":
            try:
                a = int(input(f"From node index (0-{n-1}): ")); b = int(input(f"To node index (0-{n-1}): "))
                w = int(input("Cost (lakh): "))
            except ValueError:
                print("  Invalid input: enter whole numbers."); continue
            if not (0 <= a < n and 0 <= b < n): print("  Node index out of range."); continue
            if a == b: print("  Self-loop not allowed."); continue
            if w <= 0: print("  Cost must be positive."); continue
            edges.append((a, b, w)); print(f"  Link {NODES[a]} -- {NODES[b]} (cost {w}) added.")
        elif ch == "7": return
        else: print("  Invalid choice. Enter 1-7.")

if __name__ == "__main__":
    menu()
