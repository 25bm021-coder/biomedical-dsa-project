"""Module 1 - Unit 3 - T6: AVL tree for biomedical equipment register.
Key = equipment ID. All tree logic written from scratch (no ready-made containers)."""

class Node:
    def __init__(self, eid, name, status):
        self.eid = eid
        self.name = name
        self.status = status
        self.left = None
        self.right = None
        self.height = 1

rotations = {"LL": 0, "RR": 0, "LR": 0, "RL": 0}
SHOW_STEPS = True

def height(n):
    return n.height if n else 0

def balance(n):
    return height(n.left) - height(n.right) if n else 0

def update(n):
    n.height = 1 + max(height(n.left), height(n.right))

def rot_right(y):
    x = y.left
    y.left = x.right
    x.right = y
    update(y); update(x)
    return x

def rot_left(x):
    y = x.right
    x.right = y.left
    y.left = x
    update(x); update(y)
    return y

def rebalance(n):
    update(n)
    bf = balance(n)
    if bf > 1:
        if balance(n.left) >= 0:
            rotations["LL"] += 1; kind = "LL"
            n = rot_right(n)
        else:
            rotations["LR"] += 1; kind = "LR"
            n.left = rot_left(n.left); n = rot_right(n)
        announce(kind, n)
    elif bf < -1:
        if balance(n.right) <= 0:
            rotations["RR"] += 1; kind = "RR"
            n = rot_left(n)
        else:
            rotations["RL"] += 1; kind = "RL"
            n.right = rot_right(n.right); n = rot_left(n)
        announce(kind, n)
    return n

LAST = {"root": None}

def announce(kind, sub_root):
    LAST["root"] = sub_root
    if SHOW_STEPS: print(f"  >> {kind} rotation performed; subtree now rooted at ID {sub_root.eid}")

def insert(n, eid, name, status, res):
    if n is None:
        res.append("ok"); return Node(eid, name, status)
    if eid < n.eid:
        n.left = insert(n.left, eid, name, status, res)
    elif eid > n.eid:
        n.right = insert(n.right, eid, name, status, res)
    else:
        res.append("dup"); return n
    return rebalance(n)

def min_node(n):
    while n.left:
        n = n.left
    return n

def delete(n, eid, res):
    if n is None:
        return None
    if eid < n.eid:
        n.left = delete(n.left, eid, res)
    elif eid > n.eid:
        n.right = delete(n.right, eid, res)
    else:
        res.append("ok")
        if n.left is None: return n.right
        if n.right is None: return n.left
        s = min_node(n.right)
        n.eid, n.name, n.status = s.eid, s.name, s.status
        n.right = delete(n.right, s.eid, [])
    return rebalance(n)

def search(n, eid):
    steps = 0
    while n:
        steps += 1
        if eid == n.eid: return n, steps
        n = n.left if eid < n.eid else n.right
    return None, steps

def inorder(n, out):
    if n:
        inorder(n.left, out); out.append(n); inorder(n.right, out)

def print_tree(n, indent="", side="root"):
    if n is None: return
    print_tree(n.right, indent + "      ", "R")
    print(f"{indent}[{n.eid}|bf={balance(n):+d}|h={n.height}]")
    print_tree(n.left, indent + "      ", "L")

def count_nodes(n):
    return 0 if n is None else 1 + count_nodes(n.left) + count_nodes(n.right)

STATUSES = ["In Service", "Under Maintenance", "Out of Service"]

def sample_data():
    global SHOW_STEPS
    SHOW_STEPS = False
    names = ["Ventilator", "Patient Monitor", "Infusion Pump", "Defibrillator", "ECG Machine"]
    ids = [1050, 1020, 1080, 1010, 1030, 1070, 1090, 1005, 1015, 1025,
           1035, 1060, 1075, 1085, 1095, 1040, 1045, 1055, 1065, 1100]
    root = None
    for i, e in enumerate(ids):
        root = insert(root, e, f"{names[i % 5]} {i+1:02d}", STATUSES[i % 3], [])
    SHOW_STEPS = True
    return root

def read_int(prompt):
    s = input(prompt).strip()
    if not s.isdigit():
        print("  Invalid input: enter a positive whole number.")
        return None
    return int(s)

def menu():
    global root
    root = sample_data()
    for k in rotations: rotations[k] = 0
    print("(20 synthetic equipment records loaded)")
    while True:
        print("\n===== MODULE 1: BIOMEDICAL EQUIPMENT REGISTER (AVL TREE) =====")
        print("1. Insert equipment")
        print("2. Delete equipment")
        print("3. Update service status")
        print("4. Search equipment")
        print("5. Print tree with balance factors")
        print("6. Inorder listing")
        print("7. Show rotation counts")
        print("8. Back to main menu")
        ch = input("Enter choice: ").strip()
        if ch == "1":
            eid = read_int("Equipment ID: ")
            if eid is None: continue
            name = input("Name: ").strip()
            if not name:
                print("  Name cannot be empty."); continue
            print("Status: 1.In Service 2.Under Maintenance 3.Out of Service")
            s = input("Status choice: ").strip()
            if s not in ("1", "2", "3"):
                print("  Invalid status choice."); continue
            res = []
            root = insert(root, eid, name, STATUSES[int(s) - 1], res)
            print("  Duplicate ID rejected." if "dup" in res else f"  Equipment {eid} inserted.")
            print_tree(root)
        elif ch == "2":
            eid = read_int("Equipment ID to delete: ")
            if eid is None: continue
            if root is None:
                print("  Register is empty."); continue
            res = []
            root = delete(root, eid, res)
            print(f"  Equipment {eid} deleted." if res else f"  ID {eid} not found; tree unchanged.")
            print_tree(root)
        elif ch == "3":
            eid = read_int("Equipment ID to update: ")
            if eid is None: continue
            n, _ = search(root, eid)
            if not n:
                print(f"  ID {eid} not found."); continue
            s = input("New status (1.In Service 2.Under Maintenance 3.Out of Service): ").strip()
            if s not in ("1", "2", "3"):
                print("  Invalid status choice."); continue
            n.status = STATUSES[int(s) - 1]
            print(f"  ID {eid} status updated to {n.status}.")
        elif ch == "4":
            eid = read_int("Equipment ID to search: ")
            if eid is None: continue
            n, st = search(root, eid)
            if n: print(f"  FOUND: ID {n.eid} | {n.name} | {n.status} (visited {st} nodes)")
            else: print(f"  ID {eid} not found (visited {st} nodes).")
        elif ch == "5":
            if root is None: print("  Register is empty.")
            else:
                print(f"Tree height = {root.height}, nodes = {count_nodes(root)}")
                print_tree(root)
        elif ch == "6":
            out = []; inorder(root, out)
            if not out: print("  Register is empty.")
            for n in out: print(f"  {n.eid} | {n.name} | {n.status}")
            print(f"  Total records: {len(out)}")
        elif ch == "7":
            print("  Rotation counts:", rotations)
        elif ch == "8":
            return
        else:
            print("  Invalid choice. Enter 1-8.")

root = None
if __name__ == "__main__":
    menu()
