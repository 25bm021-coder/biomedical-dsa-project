"""Main menu integrating the three modules (Group 6: T6, T12, T18)."""
import avl_module, kruskal_module, duplicate_module

def main():
    while True:
        print("\n==========================================")
        print("   BIOMEDICAL DSA PROJECT - GROUP 6 MENU")
        print("==========================================")
        print("1. Biomedical Equipment Register (AVL Tree)")
        print("2. Telemedicine Network (Kruskal's Algorithm)")
        print("3. Duplicate Patient Entries (Brute Force vs Improved Search)")
        print("4. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1": avl_module.menu()
        elif ch == "2": kruskal_module.menu()
        elif ch == "3": duplicate_module.menu()
        elif ch == "4":
            print("Thank you. Exiting program."); break
        else: print("Invalid choice. Please enter 1-4.")

if __name__ == "__main__":
    main()
