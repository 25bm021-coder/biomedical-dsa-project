"""Module 3 - Unit 5 - T18: brute force vs improved (sort-then-compare) duplicate search.
Synthetic patient entries only. Operation counters included."""
import csv

def make_records(n, dups):
    """n synthetic IDs 'P0001'.., with `dups` records copied from earlier ones (deterministic)."""
    recs = [f"P{1000 + (i * 7) % 9000:04d}" for i in range(n - dups)]
    for k in range(dups):
        recs.append(recs[(k * 3) % (n - dups)])
    return recs

def brute_force(a):
    cmp_ = 0; dups = []
    n = len(a)
    for i in range(n):
        for j in range(i + 1, n):
            cmp_ += 1
            if a[i] == a[j] and a[i] not in dups:
                dups.append(a[i])
    return dups, cmp_

def merge_sort(a, c):
    if len(a) <= 1: return a
    m = len(a) // 2
    L = merge_sort(a[:m], c); R = merge_sort(a[m:], c)
    out = []; i = j = 0
    while i < len(L) and j < len(R):
        c[0] += 1
        if L[i] <= R[j]: out.append(L[i]); i += 1
        else: out.append(R[j]); j += 1
    out.extend(L[i:]); out.extend(R[j:])
    return out

def sort_compare(a):
    c = [0]
    s = merge_sort(list(a), c)
    sort_cmp = c[0]; adj = 0; dups = []
    for i in range(len(s) - 1):
        adj += 1
        if s[i] == s[i + 1] and (not dups or dups[-1] != s[i]):
            dups.append(s[i])
    return dups, sort_cmp, adj

def experiment(sizes=(20, 40, 80, 160, 320)):
    rows = []
    for n in sizes:
        r = make_records(n, max(2, n // 10))
        _, b = brute_force(r)
        _, s1, s2 = sort_compare(r)
        rows.append((n, b, s1 + s2, s1, s2))
    return rows

def save_csv(rows, path="duplicate_performance.csv"):
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["n", "brute_force_ops", "sort_compare_ops", "sort_cmp", "adjacent_cmp"])
        w.writerows(rows)

def menu():
    data = make_records(24, 4)
    print(f"({len(data)} synthetic patient entries loaded, 4 deliberately duplicated)")
    while True:
        print("\n===== MODULE 3: DUPLICATE PATIENT ENTRIES (BRUTE FORCE vs SORT-COMPARE) =====")
        print("1. Display patient entries")
        print("2. Find duplicates - brute force")
        print("3. Find duplicates - sort then compare")
        print("4. Compare both on current data")
        print("5. Run experiment (n = 20, 40, 80, 160, 320)")
        print("6. Add a patient entry")
        print("7. Problem-type classification and analysis")
        print("8. Back to main menu")
        ch = input("Enter choice: ").strip()
        if ch == "1":
            for i in range(0, len(data), 6): print("  " + "  ".join(data[i:i + 6]))
            print(f"  Total entries: {len(data)}")
        elif ch in ("2", "3", "4"):
            if len(data) < 2: print("  Need at least 2 entries to look for duplicates."); continue
            if ch in ("2", "4"):
                d, c = brute_force(data)
                print(f"  Brute force : duplicates = {d if d else 'none'} | comparisons = {c}")
            if ch in ("3", "4"):
                d, s1, s2 = sort_compare(data)
                print(f"  Sort+compare: duplicates = {d if d else 'none'} | sort comparisons = {s1}, adjacent checks = {s2}, total = {s1 + s2}")
        elif ch == "5":
            rows = experiment(); save_csv(rows)
            print(f"  {'n':>5} {'Brute force':>12} {'Sort+compare':>13}")
            for n, b, s, _, _ in rows: print(f"  {n:>5} {b:>12} {s:>13}")
            print("  Results saved to duplicate_performance.csv")
        elif ch == "6":
            v = input("New patient ID (format Pnnnn): ").strip().upper()
            if len(v) != 5 or v[0] != "P" or not v[1:].isdigit():
                print("  Invalid format. Use P followed by 4 digits, e.g. P1234."); continue
            data.append(v); print(f"  {v} added. Total entries: {len(data)}")
        elif ch == "7":
            print("  Problem type : Searching / element-uniqueness problem")
            print("  Brute force  : T(n) = n(n-1)/2 comparisons = Theta(n^2), space O(1)")
            print("  Sort-compare : T(n) = O(n log n) + (n-1) = Theta(n log n), space O(n)")
        elif ch == "8": return
        else: print("  Invalid choice. Enter 1-8.")

if __name__ == "__main__":
    menu()
